<?php 
/**
 * Plugin Name: UnikWp Core
 * Description: This plugin register Custom posts (Projects), Custom taxonimies, popular posts widget in sidebar & footer
 * Version: 1.0
 * Author: Besim Dauti
 * Author URI: https://fabric-lab.co/
 */
?>
<?php

require_once plugin_dir_path( __FILE__ ) . 'custom-posts.php';
require_once plugin_dir_path( __FILE__ ) . 'popular-widget.php';

?>